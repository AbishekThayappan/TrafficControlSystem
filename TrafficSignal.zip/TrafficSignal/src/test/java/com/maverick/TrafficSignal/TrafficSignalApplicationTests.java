package com.maverick.TrafficSignal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrafficSignalApplicationTests {

	@Test
	void contextLoads() {
	}

}
